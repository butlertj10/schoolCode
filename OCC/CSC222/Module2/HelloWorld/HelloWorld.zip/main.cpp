#include <SDL/SDL.h>
int main(int argc, char* args[])
{
      SDL_Init(SDL_INIT_EVERYTHING);
      printf("Hello Trevor Butler");
      SDL_Quit();
      return 0;
}
